package com.nanotech.docscan.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.nanotech.docscan.data.model.Document
import com.nanotech.docscan.data.model.DocumentPage
import com.nanotech.docscan.data.model.Folder

@Dao
interface DocumentDao {
    @Query("SELECT * FROM documents ORDER BY lastModified DESC")
    fun getAllDocuments(): LiveData<List<Document>>

    @Query("SELECT * FROM documents WHERE id = :id")
    suspend fun getDocumentById(id: Long): Document?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(document: Document): Long

    @Update
    suspend fun updateDocument(document: Document)

    @Delete
    suspend fun deleteDocument(document: Document)

    @Query("SELECT * FROM document_pages WHERE documentId = :documentId ORDER BY pageOrder ASC")
    fun getPagesForDocument(documentId: Long): LiveData<List<DocumentPage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPage(page: DocumentPage): Long

    @Delete
    suspend fun deletePage(page: DocumentPage)

    @Query("SELECT * FROM folders")
    fun getAllFolders(): LiveData<List<Folder>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolder(folder: Folder): Long
}

@Database(entities = [Document::class, DocumentPage::class, Folder::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun documentDao(): DocumentDao
}
