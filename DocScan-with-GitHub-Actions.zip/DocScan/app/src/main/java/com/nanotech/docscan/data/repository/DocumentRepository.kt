package com.nanotech.docscan.data.repository

import androidx.lifecycle.LiveData
import com.nanotech.docscan.data.local.DocumentDao
import com.nanotech.docscan.data.model.Document
import com.nanotech.docscan.data.model.DocumentPage
import com.nanotech.docscan.data.model.Folder

class DocumentRepository(private val documentDao: DocumentDao) {
    val allDocuments: LiveData<List<Document>> = documentDao.getAllDocuments()
    val allFolders: LiveData<List<Folder>> = documentDao.getAllFolders()

    suspend fun getDocumentById(id: Long) = documentDao.getDocumentById(id)
    suspend fun insertDocument(document: Document) = documentDao.insertDocument(document)
    suspend fun updateDocument(document: Document) = documentDao.updateDocument(document)
    suspend fun deleteDocument(document: Document) = documentDao.deleteDocument(document)

    fun getPagesForDocument(documentId: Long) = documentDao.getPagesForDocument(documentId)
    suspend fun insertPage(page: DocumentPage) = documentDao.insertPage(page)
    suspend fun deletePage(page: DocumentPage) = documentDao.deletePage(page)

    suspend fun insertFolder(folder: Folder) = documentDao.insertFolder(folder)
}
