package com.nanotech.docscan.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "documents")
data class Document(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val dateCreated: Long = System.currentTimeMillis(),
    val folderId: Long? = null,
    val isFavorite: Boolean = false,
    val password: String? = null,
    val lastModified: Long = System.currentTimeMillis()
)

@Entity(tableName = "document_pages")
data class DocumentPage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val documentId: Long,
    val imagePath: String,
    val pageOrder: Int,
    val ocrText: String? = null
)

@Entity(tableName = "folders")
data class Folder(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val dateCreated: Long = System.currentTimeMillis()
)
