package com.nanotech.docscan.ui.viewmodel

import android.app.Application
import androidx.lifecycle.*
import androidx.room.Room
import com.nanotech.docscan.data.local.AppDatabase
import com.nanotech.docscan.data.local.DocumentDao
import com.nanotech.docscan.data.model.Document
import com.nanotech.docscan.data.model.DocumentPage
import com.nanotech.docscan.data.model.Folder
import com.nanotech.docscan.data.repository.DocumentRepository
import kotlinx.coroutines.launch

class DocumentViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: DocumentRepository
    val allDocuments: LiveData<List<Document>>
    val allFolders: LiveData<List<Folder>>

    init {
        val db = Room.databaseBuilder(
            application,
            AppDatabase::class.java, "docscan_db"
        ).build()
        repository = DocumentRepository(db.documentDao())
        allDocuments = repository.allDocuments
        allFolders = repository.allFolders
    }

    fun insertDocument(document: Document) = viewModelScope.launch {
        repository.insertDocument(document)
    }

    fun updateDocument(document: Document) = viewModelScope.launch {
        repository.updateDocument(document)
    }

    fun deleteDocument(document: Document) = viewModelScope.launch {
        repository.deleteDocument(document)
    }

    fun getPagesForDocument(documentId: Long): LiveData<List<DocumentPage>> {
        return repository.getPagesForDocument(documentId)
    }

    fun insertPage(page: DocumentPage) = viewModelScope.launch {
        repository.insertPage(page)
    }

    fun insertFolder(folder: Folder) = viewModelScope.launch {
        repository.insertFolder(folder)
    }
}
